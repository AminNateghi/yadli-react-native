import createContextHook from "@nkzw/create-context-hook";
import { asc, desc, eq } from "drizzle-orm";
import { useCallback, useEffect, useMemo, useState } from "react";

import { db } from "@/db";
import {
  expensesRecords,
  fuelsRecords,
  profileRecords,
  servicesRecords,
} from "@/db/schema";

import type {
  CarStats,
  ExpenseDto,
  ExpenseType,
  FuelDto,
  LanguageType,
  ServiceDto,
  ServiceType,
} from "@/types/interfaces";

// 1. Move stateless mappers OUTSIDE the hook. 
// This prevents them from being recreated on every render and keeps useCallback dependencies clean.
const mapService = (row: typeof servicesRecords.$inferSelect): ServiceDto => ({
	id: String(row.id),
	type: row.type as ServiceType,
	date: row.date,
	odometer: row.odometer,
	cost: row.cost,
	note: row.note ?? "",
	nextDueDate: row.nextDueDate || undefined,
	nextDueOdometer: row.nextDueOdometer ? Number(row.nextDueOdometer) : undefined,
});

const mapFuel = (row: typeof fuelsRecords.$inferSelect): FuelDto => ({
	id: String(row.id),
	date: row.date,
	odometer: row.odometer,
	liters: row.liters,
	pricePerLiter: row.pricePerLiter,
	totalCost: row.totalCost,
	fullTank: row.fullTank === 1,
	station: row.station,
	note: row.note ?? "",
});

const mapExpense = (row: typeof expensesRecords.$inferSelect): ExpenseDto => ({
	id: String(row.id),
	type: row.type as ExpenseType,
	date: row.date,
	odometer: row.odometer,
	amount: row.amount,
	note: row.note ?? "",
});

export const [DataProvider, useData] = createContextHook(() => {
	const [services, setServices] = useState([]);
	const [fuelRecords, setFuelRecords] = useState([]);
	const [expenses, setExpenses] = useState([]);
	const [language, setLanguage] = useState("en");
	const [isLoading, setIsLoading] = useState(true);

	const loadData = useCallback(async () => {
		try {
			setIsLoading(true);

			const [serviceRows, fuelRows, expenseRows, profileRows] = await Promise.all([
				db.select().from(servicesRecords).orderBy(desc(servicesRecords.date)),
				db.select().from(fuelsRecords).orderBy(desc(fuelsRecords.date)),
				db.select().from(expensesRecords).orderBy(desc(expensesRecords.date)),
				db.select().from(profileRecords).orderBy(asc(profileRecords.createdAt)),
			]);

			setServices(serviceRows.map(mapService));
			setFuelRecords(fuelRows.map(mapFuel));
			setExpenses(expenseRows.map(mapExpense));

			if (profileRows.length > 0 && profileRows[0].language) {
				setLanguage(profileRows[0].language as LanguageType);
			}
		} catch (error) {
			console.warn("Error loading car data from SQLite:", error);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		void loadData();
	}, [loadData]);

	//#region Language

	const saveLanguage = useCallback(async (data: LanguageType) => {
		try {
			const existingProfiles = await db
				.select()
				.from(profileRecords)
				.orderBy(asc(profileRecords.createdAt));

			if (existingProfiles.length > 0) {
				await db
					.update(profileRecords)
					.set({ language: data })
					.where(eq(profileRecords.id, existingProfiles[0].id!));
			} else {
				await db.insert(profileRecords).values({
					id: "default",
					language: data,
				});
			}
			setLanguage(data);
		} catch (error) {
			console.warn("Error saving language:", error);
			throw error;
		}
	}, []);

	const updateLanguage = useCallback(
		async (payload: LanguageType) => {
			await saveLanguage(payload);
		},
		[saveLanguage],
	);

	//#endregion

	//#region Services

	const addService = useCallback(async (service: Omit) => {
		const [inserted] = await db
			.insert(servicesRecords)
			.values({
				type: service.type,
				date: service.date,
				odometer: service.odometer,
				cost: service.cost,
				note: service.note ?? null,
				nextDueDate: service.nextDueDate ?? "",
				nextDueOdometer: service.nextDueOdometer !== undefined ? String(service.nextDueOdometer) : "",
			})
			.returning();

		const newService = mapService(inserted);
		setServices((prev) => [newService, ...prev]);
		return newService;
	}, []);

	const updateService = useCallback(async (id: string, service: Partial) => {
		const dbId = Number(id);
		const updateData: Partial = {};

		if (service.type !== undefined) updateData.type = service.type;
		if (service.date !== undefined) updateData.date = service.date;
		if (service.odometer !== undefined) updateData.odometer = service.odometer;
		if (service.cost !== undefined) updateData.cost = service.cost;
		if (service.note !== undefined) updateData.note = service.note ?? null;
		if (service.nextDueDate !== undefined) updateData.nextDueDate = service.nextDueDate ?? "";
		if (service.nextDueOdometer !== undefined) {
			updateData.nextDueOdometer = service.nextDueOdometer !== undefined ? String(service.nextDueOdometer) : "";
		}

		if (Object.keys(updateData).length === 0) return;

		const [updatedRow] = await db
			.update(servicesRecords)
			.set(updateData)
			.where(eq(servicesRecords.id, dbId))
			.returning();

		if (!updatedRow) return;

		const updatedService = mapService(updatedRow);
		setServices((prev) => prev.map((item) => (item.id === id ? updatedService : item)));
		return updatedService;
	}, []);

	const deleteService = useCallback(async (id: string) => {
		await db.delete(servicesRecords).where(eq(servicesRecords.id, Number(id)));
		setServices((prev) => prev.filter((service) => service.id !== id));
	}, []);

	const doneService = useCallback(async (serviceType: ServiceType) => {
		await db
			.update(servicesRecords)
			.set({
				nextDueDate: "",
				nextDueOdometer: "",
			})
			.where(eq(servicesRecords.type, serviceType));

		setServices((prev) =>
			prev.map((service) =>
				service.type === serviceType
					? { ...service, nextDueDate: undefined, nextDueOdometer: undefined }
					: service,
			),
		);
	}, []);

	//#endregion

	//#region Fuel

	const addFuelRecord = useCallback(async (fuel: Omit) => {
		const [inserted] = await db
			.insert(fuelsRecords)
			.values({
				date: fuel.date,
				odometer: fuel.odometer,
				liters: fuel.liters,
				pricePerLiter: fuel.pricePerLiter,
				totalCost: fuel.totalCost,
				fullTank: fuel.fullTank ? 1 : 0,
				station: fuel.station,
				note: fuel.note ?? null,
			})
			.returning();

		const newFuel = mapFuel(inserted);
		setFuelRecords((prev) => [newFuel, ...prev]);
		return newFuel;
	}, []);

	const updateFuelRecord = useCallback(async (id: string, fuel: Partial) => {
		const dbId = Number(id);
		const updateData: Partial = {};

		if (fuel.date !== undefined) updateData.date = fuel.date;
		if (fuel.odometer !== undefined) updateData.odometer = fuel.odometer;
		if (fuel.liters !== undefined) updateData.liters = fuel.liters;
		if (fuel.pricePerLiter !== undefined) updateData.pricePerLiter = fuel.pricePerLiter;
		if (fuel.totalCost !== undefined) updateData.totalCost = fuel.totalCost;
		if (fuel.fullTank !== undefined) updateData.fullTank = fuel.fullTank ? 1 : 0;
		if (fuel.station !== undefined) updateData.station = fuel.station;
		if (fuel.note !== undefined) updateData.note = fuel.note ?? null;

		if (Object.keys(updateData).length === 0) return;

		const [updatedRow] = await db
			.update(fuelsRecords)
			.set(updateData)
			.where(eq(fuelsRecords.id, dbId))
			.returning();

		if (!updatedRow) return;

		const updatedFuel = mapFuel(updatedRow);
		setFuelRecords((prev) => prev.map((item) => (item.id === id ? updatedFuel : item)));
		return updatedFuel;
	}, []);

	const deleteFuelRecord = useCallback(async (id: string) => {
		await db.delete(fuelsRecords).where(eq(fuelsRecords.id, Number(id)));
		setFuelRecords((prev) => prev.filter((fuel) => fuel.id !== id));
	}, []);

	//#endregion

	//#region Expenses

	const addExpense = useCallback(async (expense: Omit) => {
		const [inserted] = await db
			.insert(expensesRecords)
			.values({
				type: expense.type,
				date: expense.date,
				odometer: expense.odometer,
				amount: expense.amount,
				note: expense.note ?? null,
			})
			.returning();

		const newExpense = mapExpense(inserted);
		setExpenses((prev) => [newExpense, ...prev]);
		return newExpense;
	}, []);

	const updateExpense = useCallback(async (id: string, expense: Partial) => {
		const dbId = Number(id);
		const updateData: Partial = {};

		if (expense.type !== undefined) updateData.type = expense.type;
		if (expense.date !== undefined) updateData.date = expense.date;
		if (expense.odometer !== undefined) updateData.odometer = expense.odometer;
		if (expense.amount !== undefined) updateData.amount = expense.amount;
		if (expense.note !== undefined) updateData.note = expense.note ?? null;

		if (Object.keys(updateData).length === 0) return;

		const [updatedRow] = await db
			.update(expensesRecords)
			.set(updateData)
			.where(eq(expensesRecords.id, dbId))
			.returning();

		if (!updatedRow) return;

		const updatedExpense = mapExpense(updatedRow);
		setExpenses((prev) => prev.map((item) => (item.id === id ? updatedExpense : item)));
		return updatedExpense;
	}, []);

	const deleteExpense = useCallback(async (id: string) => {
		await db.delete(expensesRecords).where(eq(expensesRecords.id, Number(id)));
		setExpenses((prev) => prev.filter((expense) => expense.id !== id));
	}, []);

	//#endregion

	//#region Stats & Derived State

	// 2. Memoize sorting logic to prevent heavy array operations on unrelated re-renders
	const sortedServices = useMemo(() => {
		return [...services].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
	}, [services]);

	const sortedFuelRecords = useMemo(() => {
		return [...fuelRecords].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
	}, [fuelRecords]);

	const sortedExpenses = useMemo(() => {
		return [...expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
	}, [expenses]);

	const stats = useMemo((): CarStats => {
		const allKm = [
			...services.map((s) => s.odometer),
			...fuelRecords.map((f) => f.odometer),
			...expenses.filter((e) => e.odometer).map((e) => e.odometer!),
		];

		const totalOdometer = allKm.length > 0 ? Math.max(...allKm) : 0;
		let avgLiterPerKm = 0;

		if (fuelRecords.length >= 2) {
			const sorted = [...fuelRecords].sort((a, b) => a.odometer - b.odometer);
			let totalDistance = 0;
			let totalLiters = 0;

			for (let i = 1; i < sorted.length; i++) {
				if (sorted[i].fullTank && sorted[i - 1].fullTank) {
					totalDistance += sorted[i].odometer - sorted[i - 1].odometer;
					totalLiters += sorted[i].liters;
				}
			}

			avgLiterPerKm = totalLiters > 0 ? totalDistance / totalLiters : 0;
		}

		const totalFuelCost = fuelRecords.reduce((sum, fuel) => sum + fuel.totalCost, 0);
		const totalServiceCost = services.reduce((sum, service) => sum + service.cost, 0);
		const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
		
		const lastServiceDate = sortedServices.length > 0 ? sortedServices[0].date : null;
		const today = new Date();

		const upcomingService = services
			.filter((service) => service.nextDueDate)
			.sort((a, b) => new Date(a.nextDueDate!).getTime() - new Date(b.nextDueDate!).getTime());

		const timeUntilNextService =
			upcomingService.length > 0
				? new Date(upcomingService[0].nextDueDate!).getTime() - today.getTime()
				: 0;

		const daysUntilNextService = Math.ceil(timeUntilNextService / (1000 * 60 * 60 * 24));
		const nextServiceDue =
			daysUntilNextService <= 7 && daysUntilNextService > 0 ? upcomingService[0].nextDueDate! : "";

		return {
			totalKm: totalOdometer,
			avgKmPerLiter: avgLiterPerKm,
			totalFuelCost,
			totalServiceCost,
			totalExpenses,
			lastServiceDate,
			nextServiceDue,
			upcomingService,
		};
	}, [services, fuelRecords, expenses, sortedServices]);

	//#endregion

	return {
		services: sortedServices,
		fuelRecords: sortedFuelRecords,
		expenses: sortedExpenses,
		
		stats,
		language,
		isLoading,

		addService,
		updateService,
		deleteService,
		doneService,

		addFuelRecord,
		updateFuelRecord,
		deleteFuelRecord,

		addExpense,
		updateExpense,
		deleteExpense,

		updateLanguage,
	};
});