import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const profileRecords = sqliteTable("profile", {
	id: text("id"),
	fullName: text("full_name").default("-"),
	vehicleName: text("vehicle_name").default("-"),
	language: text("language").default("ir-fa"),

	createdAt: text("created_at").default(sql`(CURRENT_TIMESTAMP)`),
	updatedAt: text("updated_at")
		.notNull()
		.default(sql`(CURRENT_TIMESTAMP)`)
		.$onUpdate(() => sql`(CURRENT_TIMESTAMP)`),
});

export const servicesRecords = sqliteTable("services", {
	id: integer("id").primaryKey({
		autoIncrement: true,
	}),
	type: text("type").notNull(),
	date: text("date").notNull(),
	odometer: integer("odometer").notNull(),
	cost: integer("cost").notNull(),
	note: text("note"),
	nextDueDate: text("nextDueDate").notNull(),
	nextDueOdometer: text("nextDueOdometer").notNull(),

	createdAt: text("created_at").default(sql`(CURRENT_TIMESTAMP)`),
	updatedAt: text("updated_at")
		.notNull()
		.default(sql`(CURRENT_TIMESTAMP)`)
		.$onUpdate(() => sql`(CURRENT_TIMESTAMP)`),
});

export const fuelsRecords = sqliteTable("fuels", {
	id: integer("id").primaryKey({
		autoIncrement: true,
	}),
	date: text("date").notNull(),
	odometer: integer("odometer").notNull(),
	liters: integer("liters").notNull(),
	pricePerLiter: integer("pricePerLiter").notNull(),
	totalCost: integer("totalCost").notNull(),
	fullTank: integer("fullTank").notNull(),
	station: text("station").notNull(),
	note: text("note"),

	createdAt: text("created_at").default(sql`(CURRENT_TIMESTAMP)`),
	updatedAt: text("updated_at")
		.notNull()
		.default(sql`(CURRENT_TIMESTAMP)`)
		.$onUpdate(() => sql`(CURRENT_TIMESTAMP)`),
});

export const expensesRecords = sqliteTable("expenses", {
	id: integer("id").primaryKey({
		autoIncrement: true,
	}),
	type: text("type").notNull(),
	date: text("date").notNull(),
	odometer: integer("odometer").notNull(),
	amount: integer("amount").notNull(),
	note: text("note"),

	createdAt: text("created_at").default(sql`(CURRENT_TIMESTAMP)`),
	updatedAt: text("updated_at")
		.notNull()
		.default(sql`(CURRENT_TIMESTAMP)`)
		.$onUpdate(() => sql`(CURRENT_TIMESTAMP)`),
});
