import { DataProvider } from "@/contexts/DataContext";
import { migrateDatabase } from "@/db/migrate";
import { useColorScheme } from "@/hooks/useColorScheme";
import { useFonts } from "expo-font";
import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from "react-native-safe-area-context";

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
	const colorScheme = useColorScheme();
	const insets = useSafeAreaInsets();

	const [loaded] = useFonts({
		VazirRegular: require("@/assets/fonts/Vazirmatn-Regular.ttf"),
		VazirBold: require("@/assets/fonts/Vazirmatn-Bold.ttf"),
	});

	useEffect(() => {
		async function initialize() {
			try {
				await migrateDatabase();
			} catch (error) {
				console.error("Database initialization failed:", error);
			}
		}

		initialize();

		if (loaded) {
			SplashScreen.hideAsync();
		}
	}, [loaded]);

	if (!loaded) {
		return null;
	}

	return (
		<SafeAreaProvider style={{ marginTop: 1, marginBottom: insets.bottom }}>
			<ThemeProvider value={colorScheme === "dark" ? DarkTheme : DefaultTheme}>
				<DataProvider>
					<Stack screenOptions={{ headerShown: false }} />
					<StatusBar style="auto" />
				</DataProvider>
			</ThemeProvider>
		</SafeAreaProvider>
	);
}
